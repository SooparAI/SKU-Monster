import { eq, desc, sql, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  transactions,
  orders,
  orderItems,
  scrapedImages,
  stores,
  scrapeLogs,
  Transaction,
  Order,
  OrderItem,
  ScrapedImage,
  Store,
  ScrapeLog,
  InsertTransaction,
  InsertOrder,
  InsertOrderItem,
  InsertScrapedImage,
  InsertStore,
  InsertScrapeLog,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// User functions - for OAuth users (legacy support)
export async function upsertUser(user: InsertUser): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    // For OAuth users, we need both openId and email
    if (!user.email) {
      throw new Error("User email is required for upsert");
    }

    const values: InsertUser = {
      email: user.email,
      openId: user.openId || null,
      name: user.name || null,
      loginMethod: user.loginMethod || "oauth",
      lastSignedIn: user.lastSignedIn || new Date(),
    };

    if (user.role !== undefined) {
      values.role = user.role;
    } else if (user.openId && user.openId === ENV.ownerOpenId) {
      values.role = "admin";
    }

    const updateSet: Record<string, unknown> = {
      name: values.name,
      lastSignedIn: new Date(),
    };

    if (user.openId) {
      updateSet.openId = user.openId;
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Balance functions
export async function getUserBalance(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;

  const result = await db
    .select({ balance: users.balance })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  return result.length > 0 ? parseFloat(result[0].balance) : 0;
}

export async function updateUserBalance(
  userId: number,
  amount: number
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(users)
    .set({ balance: amount.toFixed(2) })
    .where(eq(users.id, userId));
}

export async function addToUserBalance(
  userId: number,
  amount: number
): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const currentBalance = await getUserBalance(userId);
  const newBalance = currentBalance + amount;

  await updateUserBalance(userId, newBalance);
  return newBalance;
}

export async function deductFromUserBalance(
  userId: number,
  amount: number
): Promise<{ success: boolean; newBalance: number }> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const currentBalance = await getUserBalance(userId);
  if (currentBalance < amount) {
    return { success: false, newBalance: currentBalance };
  }

  const newBalance = currentBalance - amount;
  await updateUserBalance(userId, newBalance);
  return { success: true, newBalance };
}

// Transaction functions
export async function createTransaction(
  data: InsertTransaction
): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(transactions).values(data);
  return result[0].insertId;
}

export async function updateTransactionStatus(
  id: number,
  status: "pending" | "completed" | "failed"
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(transactions).set({ status }).where(eq(transactions.id, id));
}

export async function getUserTransactions(userId: number): Promise<Transaction[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.createdAt));
}

export async function getTransactionByPaymentId(
  paymentId: string
): Promise<Transaction | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(transactions)
    .where(eq(transactions.paymentId, paymentId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Order functions
export async function createOrder(data: InsertOrder): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(orders).values(data);
  return result[0].insertId;
}

export async function updateOrder(
  id: number,
  data: Partial<Order>
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(orders).set(data).where(eq(orders.id, id));
}

export async function getOrderById(id: number): Promise<Order | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(orders)
    .where(eq(orders.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserOrders(userId: number): Promise<Order[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(orders)
    .where(eq(orders.userId, userId))
    .orderBy(desc(orders.createdAt));
}

// Order item functions
export async function createOrderItems(
  items: InsertOrderItem[]
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (items.length > 0) {
    await db.insert(orderItems).values(items);
  }
}

export async function updateOrderItem(
  id: number,
  data: Partial<OrderItem>
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(orderItems).set(data).where(eq(orderItems.id, id));
}

export async function getOrderItems(orderId: number): Promise<OrderItem[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
}

// Scraped images functions
export async function saveScrapedImages(
  images: InsertScrapedImage[]
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (images.length > 0) {
    await db.insert(scrapedImages).values(images);
  }
}

export async function getScrapedImagesByOrderItem(
  orderItemId: number
): Promise<ScrapedImage[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(scrapedImages)
    .where(eq(scrapedImages.orderItemId, orderItemId));
}

// Store functions
export async function getActiveStores(): Promise<Store[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(stores).where(eq(stores.isActive, 1));
}

export async function upsertStore(data: InsertStore): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .insert(stores)
    .values(data)
    .onDuplicateKeyUpdate({
      set: {
        baseUrl: data.baseUrl,
        searchUrlTemplate: data.searchUrlTemplate,
        category: data.category,
        isActive: data.isActive,
        selectors: data.selectors,
      },
    });
}

// Get orders stuck in 'processing' for longer than maxAgeMs
export async function getStuckProcessingOrders(maxAgeMs: number = 5 * 60 * 1000): Promise<Order[]> {
  const db = await getDb();
  if (!db) return [];

  const cutoff = new Date(Date.now() - maxAgeMs);
  return db
    .select()
    .from(orders)
    .where(
      and(
        eq(orders.status, "processing"),
        sql`${orders.createdAt} < ${cutoff}`
      )
    );
}

// Get all failed orders for a user that don't have corresponding refund transactions
export async function getFailedOrdersWithoutRefund(userId?: number): Promise<Order[]> {
  const db = await getDb();
  if (!db) return [];

  // Get all refund transaction descriptions to extract order IDs
  const refundTxns = await db
    .select({ description: transactions.description })
    .from(transactions)
    .where(eq(transactions.type, "refund"));

  const refundedOrderIds = new Set<number>();
  for (const txn of refundTxns) {
    const match = txn.description?.match(/#(\d+)/);
    if (match) refundedOrderIds.add(parseInt(match[1]));
  }

  const conditions = [eq(orders.status, "failed")];
  if (userId) conditions.push(eq(orders.userId, userId));

  const failedOrders = await db
    .select()
    .from(orders)
    .where(and(...conditions));

  return failedOrders.filter(o => !refundedOrderIds.has(o.id));
}

// Scrape log functions
export async function addScrapeLog(data: InsertScrapeLog): Promise<void> {
  try {
    const db = await getDb();
    if (!db) return;
    await db.insert(scrapeLogs).values(data);
  } catch (error) {
    // Never let logging failures break the pipeline
    console.error('[ScrapeLog] Failed to write log:', error);
  }
}

export async function getScrapeLogsByOrder(orderId: number): Promise<ScrapeLog[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(scrapeLogs).where(eq(scrapeLogs.orderId, orderId)).orderBy(scrapeLogs.id);
}

// Helper to log a pipeline step with timing
export function createStepLogger(orderId: number, sku: string) {
  return {
    async log(step: string, status: 'start' | 'success' | 'error', message: string, details?: any, durationMs?: number) {
      await addScrapeLog({ orderId, sku, step, status, message, details: details ?? null, durationMs: durationMs ?? null });
    },
    async timed<T>(step: string, fn: () => Promise<T>): Promise<T> {
      const start = Date.now();
      await addScrapeLog({ orderId, sku, step, status: 'start', message: `Starting ${step}...` });
      try {
        const result = await fn();
        const ms = Date.now() - start;
        await addScrapeLog({ orderId, sku, step, status: 'success', message: `${step} completed in ${ms}ms`, durationMs: ms });
        return result;
      } catch (error) {
        const ms = Date.now() - start;
        const errMsg = error instanceof Error ? error.message : String(error);
        await addScrapeLog({ orderId, sku, step, status: 'error', message: `${step} failed: ${errMsg}`, details: { error: errMsg }, durationMs: ms });
        throw error;
      }
    }
  };
}

// Pricing constant
export const SKU_PRICE = 2; // $2 per SKU (5 HQ images, 2000x2000, >900KB each)

// Scraper Service - PRODUCTION-READY
// Uses UPC database first, then Perplexity image search, then browser as last resort
// All image sources work without Chrome - browser is purely optional

import type { Browser, Page } from "puppeteer";
import { nanoid } from "nanoid";
import archiver from "archiver";
import { Writable } from "stream";
import { exec } from "child_process";
import { promisify } from "util";

import { storagePut } from "../storage";
import { storeConfigs, getActiveStores, type StoreConfig } from "./storeConfigs";
import { processImagesHQ, uploadHQImages, type QualityMode } from "./hqImagePipeline";
import { lookupUpc, lookupBarcodeLookup, lookupEanSearch, extractProductKeywords } from "./upcLookup";
import { searchProductImages, searchEbayImages, searchRetailerImages, searchAllImageSources } from "./imageSearch";
import { createStepLogger, addScrapeLog } from "../db";

const execAsync = promisify(exec);

// Lazy-load puppeteer to avoid crashes when Chrome is not installed
let puppeteerModule: any = null;
let puppeteerLoaded = false;

async function getPuppeteer(): Promise<any> {
  if (puppeteerLoaded) return puppeteerModule;
  puppeteerLoaded = true;
  try {
    const mod = await import("puppeteer");
    puppeteerModule = mod.default || mod;
    console.log("[Puppeteer] Module loaded successfully");
  } catch (e) {
    console.warn("[Puppeteer] Module not available:", e);
    puppeteerModule = null;
  }
  return puppeteerModule;
}

// Types
export interface ScrapedImageResult {
  sku: string;
  storeName: string;
  sourceUrl: string;
  imageUrl: string;
  s3Key?: string;
  s3Url?: string;
  width?: number;
  height?: number;
}

export interface SkuScrapeResult {
  sku: string;
  images: ScrapedImageResult[];
  errors: string[];
  status: "completed" | "partial" | "failed";
}

export interface ScrapeJobResult {
  orderId: number;
  results: SkuScrapeResult[];
  zipKey: string;
  zipUrl: string;
  totalImages: number;
  processedSkus: number;
  failedSkus: number;
}

// ===== OPTIMIZED CONSTANTS =====
const SKU_TIMEOUT_MS = 6 * 60 * 1000; // 6 minutes max per SKU (Replicate cold start can take 30-60s)
const PAGE_TIMEOUT_MS = 10000;
const PARALLEL_LIMIT = 5;
const MAX_STORE_IMAGES = 10;
const TOP_STORES_COUNT = 12;

const TOP_STORE_NAMES = new Set([
  "FragranceNet", "FragranceX", "Sephora", "Nordstrom",
  "Ulta Beauty", "Macy's", "Bloomingdale's", "Neiman Marcus",
  "Harrods", "Selfridges", "Realry", "The Perfume Shop",
]);

// Browser instance management
let browserInstance: Browser | null = null;
let browserPid: number | null = null;

async function getBrowser(): Promise<Browser | null> {
  const puppeteer = await getPuppeteer();
  if (!puppeteer) {
    console.log("[Browser] Puppeteer not available, skipping browser launch");
    return null;
  }

  if (browserInstance) {
    try {
      if (browserInstance.connected) await browserInstance.close();
    } catch { /* ignore */ }
    browserInstance = null;
  }

  try {
    browserInstance = await puppeteer.launch({
      headless: true,
      args: [
        "--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage",
        "--disable-accelerated-2d-canvas", "--disable-gpu", "--window-size=1920x1080",
        "--disable-blink-features=AutomationControlled",
        "--disable-features=IsolateOrigins,site-per-process",
        "--disable-extensions", "--disable-background-networking",
        "--disable-default-apps", "--disable-sync", "--disable-translate",
        "--metrics-recording-only", "--no-first-run",
      ],
    });
    browserPid = browserInstance!.process()?.pid || null;
    console.log(`[Browser] Launched (PID: ${browserPid})`);
    return browserInstance;
  } catch (err) {
    console.error(`[Browser] Launch failed: ${err}`);
    return null;
  }
}

async function closeBrowser(): Promise<void> {
  if (browserInstance) {
    try { await browserInstance.close(); } catch { /* ignore */ }
    browserInstance = null;
  }
  if (browserPid) {
    try { await execAsync(`kill -9 ${browserPid} 2>/dev/null || true`); } catch { /* ignore */ }
    browserPid = null;
  }
}

async function cleanupOrphanedProcesses(): Promise<void> {
  try {
    await execAsync('pkill -9 -f "puppeteer.*chrome" 2>/dev/null || true');
    await execAsync('rm -rf /tmp/puppeteer_* 2>/dev/null || true');
    console.log('[Cleanup] Cleaned up orphaned processes');
  } catch { /* ignore */ }
}

try { cleanupOrphanedProcesses(); } catch { /* ignore */ }

function withTimeout<T>(promise: Promise<T>, timeoutMs: number, operation: string): Promise<T> {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error(`'${operation}' timed out after ${timeoutMs}ms`));
      }
    }, timeoutMs);
    promise
      .then((result) => { if (!settled) { settled = true; clearTimeout(timer); resolve(result); } })
      .catch((err) => { if (!settled) { settled = true; clearTimeout(timer); reject(err); } });
  });
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomDelay(min: number, max: number): Promise<void> {
  return delay(Math.floor(Math.random() * (max - min + 1)) + min);
}

const userAgents = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
];

function getRandomUserAgent(): string {
  return userAgents[Math.floor(Math.random() * userAgents.length)];
}

// ===== EXCLUSION ZONES for image extraction =====
const EXCLUDED_SECTION_SELECTORS = [
  '[class*="similar"]', '[class*="recommend"]', '[class*="related"]',
  '[class*="also-like"]', '[class*="you-may"]', '[class*="recently"]',
  '[class*="cross-sell"]', '[class*="upsell"]', '[class*="carousel"]',
  '[id*="similar"]', '[id*="recommend"]', '[id*="related"]',
  '[data-component*="recommend"]', '[data-component*="similar"]',
  'footer', '[class*="footer"]',
].join(', ');

const MAIN_PRODUCT_SELECTORS = [
  '[class*="product-image"]', '[class*="product-gallery"]',
  '[class*="pdp-image"]', '[class*="main-image"]',
  '[class*="hero-image"]', '[class*="product-media"]',
  '[data-component="product-image"]', '[data-testid*="product-image"]',
  '.product-detail img', '.product-page img',
  '[class*="zoom"]', '[class*="magnif"]',
];

async function extractProductImages(page: Page, store: StoreConfig): Promise<string[]> {
  const images: string[] = [];
  try {
    const extracted = await page.evaluate((mainSelectors: string[], excludedSelectors: string, storeSelectors: any) => {
      const results: string[] = [];
      const seen = new Set<string>();
      const addImg = (url: string | null | undefined) => {
        if (!url || url.startsWith('data:') || seen.has(url)) return;
        seen.add(url);
        results.push(url);
      };
      const excludedElements = document.querySelectorAll(excludedSelectors);
      const isInExcludedZone = (el: Element): boolean => {
        for (const excluded of Array.from(excludedElements)) {
          if (excluded.contains(el)) return true;
        }
        return false;
      };
      if (storeSelectors.productImage) {
        const storeImgs = document.querySelectorAll(storeSelectors.productImage);
        for (const img of Array.from(storeImgs)) {
          if (isInExcludedZone(img)) continue;
          const src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-zoom-image');
          addImg(src);
        }
      }
      for (const selector of mainSelectors) {
        const container = document.querySelector(selector);
        if (!container || isInExcludedZone(container)) continue;
        const imgs = container.querySelectorAll('img');
        for (const img of Array.from(imgs)) {
          const src = img.getAttribute('src') || img.getAttribute('data-src');
          addImg(src);
        }
      }
      if (results.length < 3) {
        const allImgs = document.querySelectorAll('img');
        for (const img of Array.from(allImgs)) {
          if (isInExcludedZone(img)) continue;
          const rect = img.getBoundingClientRect();
          if (rect.top > 1200) continue;
          if (rect.width < 200 || rect.height < 200) continue;
          const src = img.getAttribute('src') || img.getAttribute('data-src');
          addImg(src);
        }
      }
      return results;
    }, MAIN_PRODUCT_SELECTORS, EXCLUDED_SECTION_SELECTORS, store.selectors);
    for (let url of extracted) {
      if (url.startsWith('//')) url = 'https:' + url;
      else if (url.startsWith('/')) {
        const baseUrl = new URL(store.baseUrl);
        url = baseUrl.origin + url;
      }
      if (!images.includes(url)) images.push(url);
    }
    console.log(`  Extracted ${images.length} product images`);
  } catch (err) {
    console.error(`  Error extracting images: ${err}`);
  }
  return images;
}

async function scrapeStore(page: Page, store: StoreConfig, sku: string): Promise<ScrapedImageResult[]> {
  const results: ScrapedImageResult[] = [];
  try {
    const searchUrl = store.searchUrlTemplate.replace("{sku}", sku);
    await withTimeout(
      page.goto(searchUrl, { waitUntil: "domcontentloaded", timeout: PAGE_TIMEOUT_MS }),
      PAGE_TIMEOUT_MS + 3000,
      `Navigate to ${store.name}`
    );
    await delay(1500);
    const noResults = await page.$(store.selectors.noResults);
    if (noResults) return [];
    const pageContent = await page.evaluate(() => {
      return (document.body.innerText + ' ' + document.title).toLowerCase();
    });
    const skuLower = sku.toLowerCase();
    if (!pageContent.includes(skuLower)) {
      console.log(`  [${store.name}] SKU not found on page - skipping`);
      return [];
    }
    const productLink = await page.$(store.selectors.productLink);
    if (productLink) {
      try {
        await productLink.click();
        await page.waitForNavigation({ waitUntil: "domcontentloaded", timeout: PAGE_TIMEOUT_MS }).catch(() => {});
        await delay(1000);
      } catch { /* ignore */ }
    }
    const imageUrls = await extractProductImages(page, store);
    for (const url of imageUrls) {
      results.push({ sku, storeName: store.name, sourceUrl: page.url(), imageUrl: url });
    }
  } catch (err) {
    if (err instanceof Error && err.message.includes('timed out')) {
      console.log(`  [${store.name}] Timed out - skipping`);
    } else {
      console.error(`  [${store.name}] Error: ${err instanceof Error ? err.message : err}`);
    }
  }
  return results;
}

function getTopStores(): StoreConfig[] {
  const active = getActiveStores();
  const top = active.filter(s => TOP_STORE_NAMES.has(s.name));
  if (top.length < TOP_STORES_COUNT) {
    const remaining = active.filter(s => !TOP_STORE_NAMES.has(s.name));
    top.push(...remaining.slice(0, TOP_STORES_COUNT - top.length));
  }
  return top.slice(0, TOP_STORES_COUNT);
}

// ===== MAIN SCRAPE FUNCTION =====
export async function scrapeSku(sku: string, orderId?: number, qualityMode: QualityMode = 'studio'): Promise<SkuScrapeResult> {
  const startTime = Date.now();
  const allImages: ScrapedImageResult[] = [];
  const errors: string[] = [];
  let productName: string | null = null;
  let brand: string | null = null;

  // Create a DB logger if we have an orderId
  const log = orderId ? createStepLogger(orderId, sku) : null;

  // STEP 1: UPC database lookup (fast, reliable, no browser needed)
  console.log(`[${sku}] STEP 1: UPC database lookup...`);
  const upcStart = Date.now();
  try {
    const upcResult = await lookupUpc(sku);
    if (upcResult.found) {
      productName = upcResult.productName || null;
      brand = upcResult.brand || null;
      console.log(`[${sku}] UPC found: ${productName} by ${brand} (${upcResult.images.length} images)`);
      for (const imageUrl of upcResult.images) {
        allImages.push({ sku, storeName: "UPC Database", sourceUrl: "upcitemdb.com", imageUrl });
      }
      await log?.log('upc_lookup', 'success', `Found: ${productName} by ${brand} (${upcResult.images.length} images)`, { productName, brand, imageCount: upcResult.images.length, imageUrls: upcResult.images.slice(0, 5) }, Date.now() - upcStart);
    } else {
      console.log(`[${sku}] UPC: not found on upcitemdb, trying barcodelookup.com...`);
      // Fallback: try barcodelookup.com
      const bclResult = await lookupBarcodeLookup(sku);
      if (bclResult.found) {
        productName = bclResult.productName || null;
        brand = bclResult.brand || null;
        console.log(`[${sku}] BarcodeLookup found: ${productName} by ${brand} (${bclResult.images.length} images)`);
        for (const imageUrl of bclResult.images) {
          allImages.push({ sku, storeName: "BarcodeLookup", sourceUrl: "barcodelookup.com", imageUrl });
        }
        await log?.log('upc_lookup', 'success', `BarcodeLookup found: ${productName} by ${brand} (${bclResult.images.length} images)`, { source: 'barcodelookup.com', productName, brand, imageCount: bclResult.images.length }, Date.now() - upcStart);
      } else {
        console.log(`[${sku}] UPC: not found on either database`);
        await log?.log('upc_lookup', 'success', 'Product not found in UPC databases (upcitemdb + barcodelookup)', null, Date.now() - upcStart);
      }
    }
  } catch (upcErr) {
    console.error(`[${sku}] UPC lookup error: ${upcErr}`);
    const msg = upcErr instanceof Error ? upcErr.message : String(upcErr);
    errors.push(`UPC lookup failed: ${msg}`);
    await log?.log('upc_lookup', 'error', `UPC lookup failed: ${msg}`, { error: msg }, Date.now() - upcStart);
  }

  // STEP 2: Perplexity API search + retailer page image extraction
  console.log(`[${sku}] STEP 2: Perplexity + retailer image search (UPC found ${allImages.length} images, product: ${productName || 'unknown'})...`);
  const searchStart = Date.now();
  try {
    const searchResult = await searchAllImageSources(sku, productName);
    // Update product info if Perplexity found better data
    if (searchResult.productName && !productName) {
      productName = searchResult.productName;
    }
    if (searchResult.brand && !brand) {
      brand = searchResult.brand;
    }
    for (const imageUrl of searchResult.imageUrls) {
      allImages.push({ sku, storeName: "Retailer", sourceUrl: "perplexity", imageUrl });
    }
    console.log(`[${sku}] Image search found ${searchResult.imageUrls.length} images from retailers (product: ${searchResult.productName}, brand: ${searchResult.brand})`);
    await log?.log('perplexity_search', 'success', `Found ${searchResult.imageUrls.length} images, product: ${searchResult.productName} by ${searchResult.brand}`, {
      imageCount: searchResult.imageUrls.length,
      productName: searchResult.productName,
      brand: searchResult.brand,
      description: searchResult.description,
      sources: searchResult.sources,
      sampleUrls: searchResult.imageUrls.slice(0, 5),
    }, Date.now() - searchStart);
  } catch (searchErr) {
    console.error(`[${sku}] Image search error: ${searchErr}`);
    const msg = searchErr instanceof Error ? searchErr.message : String(searchErr);
    errors.push(`Image search failed: ${msg}`);
    await log?.log('perplexity_search', 'error', `Image search failed: ${msg}`, { error: msg }, Date.now() - searchStart);
  }

  // STEP 3: Browser scraping (OPTIONAL - only if we still need more images AND browser is available)
  if (allImages.length < 1) {
    console.log(`[${sku}] STEP 3: Browser scraping (have ${allImages.length} images so far)...`);
    await log?.log('browser_scrape', 'start', `No images found, attempting browser scrape...`);
    const browserStart = Date.now();
    const browser = await getBrowser();
    if (browser) {
      try {
        const stores = getTopStores();
        console.log(`[${sku}] Scraping ${stores.length} top stores...`);
        for (let i = 0; i < stores.length; i += PARALLEL_LIMIT) {
          if (Date.now() - startTime > SKU_TIMEOUT_MS) {
            console.log(`[${sku}] Timeout exceeded, stopping store scraping`);
            errors.push(`Timeout after ${Math.floor((Date.now() - startTime) / 1000)}s`);
            break;
          }
          const batch = stores.slice(i, i + PARALLEL_LIMIT);
          console.log(`  Batch: ${batch.map(s => s.name).join(', ')}`);
          const batchResults = await Promise.all(
            batch.map(async (store) => {
              const storePage = await browser.newPage();
              await storePage.setUserAgent(getRandomUserAgent());
              await storePage.setViewport({ width: 1920, height: 1080 });
              try {
                return await scrapeStore(storePage, store, sku);
              } catch (err) {
                errors.push(`${store.name}: ${err instanceof Error ? err.message : "Error"}`);
                return [];
              } finally {
                try { await storePage.close(); } catch { /* ignore */ }
              }
            })
          );
          for (const images of batchResults) {
            allImages.push(...images);
          }
          if (allImages.length >= MAX_STORE_IMAGES) {
            console.log(`[${sku}] Early exit: ${allImages.length} images found`);
            break;
          }
        }
        await log?.log('browser_scrape', 'success', `Browser found ${allImages.length} images`, null, Date.now() - browserStart);
      } finally {
        await closeBrowser();
      }
    } else {
      console.log(`[${sku}] Browser not available, skipping store scraping`);
      errors.push("Browser not available (Chrome not installed)");
      await log?.log('browser_scrape', 'error', 'Browser not available (Chrome not installed)', null, Date.now() - browserStart);
    }
  } else {
    console.log(`[${sku}] ${allImages.length} images found, skipping browser scraping`);
    await log?.log('browser_scrape', 'success', `Skipped - already have ${allImages.length} images`);
  }

  // STEP 3.5: EAN-Search.org LAST RESORT (only when ALL other methods found 0 images AND no product name)
  // This API has a strict 100 queries/month limit - only use when absolutely necessary
  if (allImages.length === 0 && !productName) {
    console.log(`[${sku}] STEP 3.5: EAN-Search.org LAST RESORT (0 images, no product name)...`);
    const eanStart = Date.now();
    try {
      const eanResult = await lookupEanSearch(sku);
      if (eanResult.found) {
        productName = eanResult.productName || null;
        brand = eanResult.brand || null;
        console.log(`[${sku}] EAN-Search found: ${productName} (${eanResult.description})`);
        await log?.log('ean_search', 'success', `EAN-Search found: ${productName}`, { productName, brand, description: eanResult.description }, Date.now() - eanStart);
        
        // Now that we have a product name, retry Perplexity image search with the correct name
        console.log(`[${sku}] Retrying image search with product name: ${productName}...`);
        try {
          const retryResult = await searchAllImageSources(sku, productName);
          for (const imageUrl of retryResult.imageUrls) {
            allImages.push({ sku, storeName: "Retailer", sourceUrl: "ean-search-retry", imageUrl });
          }
          console.log(`[${sku}] Retry search found ${retryResult.imageUrls.length} images`);
          await log?.log('ean_search_retry', 'success', `Retry with product name found ${retryResult.imageUrls.length} images`, { imageCount: retryResult.imageUrls.length }, Date.now() - eanStart);
        } catch (retryErr) {
          console.error(`[${sku}] Retry search error: ${retryErr}`);
        }
      } else {
        console.log(`[${sku}] EAN-Search: not found either`);
        await log?.log('ean_search', 'success', 'Product not found in EAN-Search.org', null, Date.now() - eanStart);
      }
    } catch (eanErr) {
      console.error(`[${sku}] EAN-Search error: ${eanErr}`);
      const msg = eanErr instanceof Error ? eanErr.message : String(eanErr);
      await log?.log('ean_search', 'error', `EAN-Search failed: ${msg}`, { error: msg }, Date.now() - eanStart);
    }
  }

  // Deduplicate
  const uniqueUrls = new Set<string>();
  const uniqueImages = allImages.filter(img => {
    if (uniqueUrls.has(img.imageUrl)) return false;
    uniqueUrls.add(img.imageUrl);
    return true;
  });

  const elapsed = Math.floor((Date.now() - startTime) / 1000);
  console.log(`[${sku}] ${uniqueImages.length} unique images in ${elapsed}s`);
  await log?.log('dedup', 'success', `${uniqueImages.length} unique images after dedup (${elapsed}s elapsed)`, { totalRaw: allImages.length, unique: uniqueImages.length });

  // STEP 4: HQ pipeline (parallel scoring + parallel upscaling)
  const hqStart = Date.now();
  const imageUrls = uniqueImages.map(img => img.imageUrl);
  let hqResult;
  try {
    hqResult = await processImagesHQ(sku, imageUrls, productName, brand, qualityMode);
    console.log(`[${sku}] HQ pipeline: ${hqResult.images.length} images, cost: $${hqResult.totalCost.toFixed(4)}`);
    await log?.log('hq_pipeline', 'success', `${hqResult.images.length} HQ images, cost: $${hqResult.totalCost.toFixed(4)}`, {
      imageCount: hqResult.images.length,
      cost: hqResult.totalCost,
      sources: hqResult.images.map(i => i.source),
      steps: hqResult.processingSteps,
    }, Date.now() - hqStart);
  } catch (hqErr) {
    const msg = hqErr instanceof Error ? hqErr.message : String(hqErr);
    console.error(`[${sku}] HQ pipeline error: ${msg}`);
    errors.push(`HQ pipeline failed: ${msg}`);
    await log?.log('hq_pipeline', 'error', `HQ pipeline failed: ${msg}`, { error: msg }, Date.now() - hqStart);
    return { sku, images: [], errors, status: 'failed' };
  }

  // STEP 5: Upload to S3 (parallel)
  const uploadStart = Date.now();
  let uploadedHQ;
  try {
    uploadedHQ = await uploadHQImages(sku, hqResult.images);
    await log?.log('s3_upload', 'success', `${uploadedHQ.length} images uploaded to S3`, {
      count: uploadedHQ.length,
      urls: uploadedHQ.map(u => u.s3Url),
    }, Date.now() - uploadStart);
  } catch (uploadErr) {
    const msg = uploadErr instanceof Error ? uploadErr.message : String(uploadErr);
    console.error(`[${sku}] S3 upload error: ${msg}`);
    errors.push(`S3 upload failed: ${msg}`);
    await log?.log('s3_upload', 'error', `S3 upload failed: ${msg}`, { error: msg }, Date.now() - uploadStart);
    return { sku, images: [], errors, status: 'failed' };
  }

  // Build final images
  const finalImages: ScrapedImageResult[] = [];
  for (const uploaded of uploadedHQ) {
    const hqImg = hqResult.images.find(img =>
      uploaded.s3Key.includes(img.source) || true
    );
    const sourceImg = uniqueImages.find(img =>
      hqImg && img.imageUrl === hqImg.originalUrl
    );
    finalImages.push({
      sku,
      storeName: sourceImg?.storeName || "HQ Pipeline",
      sourceUrl: sourceImg?.sourceUrl || "",
      imageUrl: uploaded.s3Url,
      s3Key: uploaded.s3Key,
      s3Url: uploaded.s3Url,
      width: uploaded.width,
      height: uploaded.height,
    });
  }

  const totalElapsed = Math.floor((Date.now() - startTime) / 1000);
  console.log(`[${sku}] DONE: ${finalImages.length} HQ images uploaded to S3 in ${totalElapsed}s`);
  await log?.log('complete', finalImages.length > 0 ? 'success' : 'error',
    `Completed: ${finalImages.length} HQ images in ${totalElapsed}s`,
    { finalCount: finalImages.length, totalElapsed, errors },
    Date.now() - startTime
  );

  return {
    sku,
    images: finalImages,
    errors,
    status: finalImages.length > 0 ? "completed" : "failed",
  };
}

// Create zip from results
async function createZipFromResults(
  results: SkuScrapeResult[],
  orderId: number
): Promise<{ zipKey: string; zipUrl: string }> {
  return new Promise(async (resolve, reject) => {
    const chunks: Buffer[] = [];
    const writableStream = new Writable({
      write(chunk, _encoding, callback) {
        chunks.push(chunk);
        callback();
      },
    });

    const archive = archiver("zip", { zlib: { level: 6 } });
    archive.on("error", reject);
    archive.on("end", async () => {
      const zipBuffer = Buffer.concat(chunks);
      const zipKey = `orders/${orderId}/Photo.1_Output_${nanoid(8)}.zip`;
      try {
        const { url } = await storagePut(zipKey, zipBuffer, "application/zip");
        resolve({ zipKey, zipUrl: url });
      } catch (err) {
        reject(err);
      }
    });

    archive.pipe(writableStream);

    let addedCount = 0;
    for (const result of results) {
      for (let i = 0; i < result.images.length; i++) {
        const image = result.images[i];
        if (image.s3Url) {
          try {
            const response = await fetch(image.s3Url, { signal: AbortSignal.timeout(15000) });
            if (response.ok) {
              const buffer = Buffer.from(await response.arrayBuffer());
              const ext = image.s3Url.split(".").pop()?.split("?")[0] || "jpg";
              const filename = `${result.sku}/${image.storeName}_${i + 1}.${ext}`;
              archive.append(buffer, { name: filename });
              addedCount++;
            }
          } catch (err) {
            console.error(`Failed to add image to zip: ${err}`);
          }
        }
      }
    }
    console.log(`Added ${addedCount} HQ images to zip`);
    archive.finalize();
  });
}

// ===== MAIN JOB RUNNER with hard timeout =====
export async function runScrapeJob(
  orderId: number,
  skus: string[],
  onProgress?: (processed: number, total: number) => void,
  qualityMode: QualityMode = 'studio'
): Promise<ScrapeJobResult> {
  const results: SkuScrapeResult[] = [];
  let totalImages = 0;
  let processedSkus = 0;
  let failedSkus = 0;

  console.log(`[Job ${orderId}] Starting with ${skus.length} SKUs`);

  const jobTimeout = setTimeout(async () => {
    console.error(`[Job ${orderId}] HARD TIMEOUT - force killing all processes`);
    await closeBrowser();
    await cleanupOrphanedProcesses();
  }, SKU_TIMEOUT_MS * skus.length + 60000);

  try {
    for (let i = 0; i < skus.length; i++) {
      const sku = skus[i];
      console.log(`[Job ${orderId}] SKU ${i + 1}/${skus.length}: ${sku}`);

      try {
        const result = await withTimeout(
          scrapeSku(sku, orderId, qualityMode),
          SKU_TIMEOUT_MS,
          `Scrape SKU ${sku}`
        );
        results.push(result);
        totalImages += result.images.length;
        processedSkus++;
        if (result.status === "failed") failedSkus++;
      } catch (err) {
        console.error(`[Job ${orderId}] SKU ${sku} failed: ${err}`);
        results.push({
          sku,
          images: [],
          errors: [err instanceof Error ? err.message : "Unknown error"],
          status: "failed",
        });
        failedSkus++;
        processedSkus++;
      }

      if (onProgress) onProgress(i + 1, skus.length);
    }

    console.log(`[Job ${orderId}] Creating zip...`);
    let zipKey = "";
    let zipUrl = "";
    try {
      const zipResult = await createZipFromResults(results, orderId);
      zipKey = zipResult.zipKey;
      zipUrl = zipResult.zipUrl;
      console.log(`[Job ${orderId}] Zip created: ${zipUrl}`);
    } catch (zipErr) {
      console.error(`[Job ${orderId}] Zip failed:`, zipErr);
    }

    return { orderId, results, zipKey, zipUrl, totalImages, processedSkus, failedSkus };
  } finally {
    clearTimeout(jobTimeout);
    await closeBrowser();
    await cleanupOrphanedProcesses();
    console.log(`[Job ${orderId}] Complete. Resources cleaned up.`);
  }
}

// Parse SKUs from text input
export function parseSkusFromText(text: string): string[] {
  const parts = text
    .split(/[\n\r,;\t]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  const skus: string[] = [];
  for (const part of parts) {
    const matches = part.match(/\d{8,14}/g);
    if (matches) skus.push(...matches);
  }

  return Array.from(new Set(skus));
}
